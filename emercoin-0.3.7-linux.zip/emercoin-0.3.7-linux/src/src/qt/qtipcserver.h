#define BITCOINURI_QUEUE_NAME "BitcoinURI"

void ipcInit();
void ipcShutdown();